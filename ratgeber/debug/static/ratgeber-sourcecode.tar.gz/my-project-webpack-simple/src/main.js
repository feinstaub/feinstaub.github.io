"use strict"

import Vue from 'vue'
import App from './App.vue'
import BootstrapVue from 'bootstrap-vue' // https://bootstrap-vue.js.org/docs
/* ...there may be other imports here */ // https://bootstrap-vue.js.org/docs
import MyDetailsView from './MyDetailsView.vue'
import MyInfoLabel from './MyInfoLabel.vue'

// todo: maybe try this: https://www.npmjs.com/package/vue2-leaflet
// yarn add leaflet, yarn add sprintf
import 'leaflet/dist/leaflet.css'
import 'leaflet/dist/leaflet.js'

Vue.use(BootstrapVue); // https://bootstrap-vue.js.org/docs

import 'bootstrap/dist/css/bootstrap.css' // https://bootstrap-vue.js.org/docs
import 'bootstrap-vue/dist/bootstrap-vue.css' // https://bootstrap-vue.js.org/docs

// DOC: https://vuejs.org/v2/guide/components.html
// register first
Vue.component('my-component', {
  template: '<div>A custom component!</div>'
})

Vue.component('hello-world', {
    template: `
        <div id="hello-world-template">
            <p>Hello world custom template</p>
        </div>`
})

// DOC: https://vuejs.org/v2/guide/components.html#Form-Input-Components-using-Custom-Events
// erst mal zurückgestellt, weil etwas zu kompliziert
Vue.component('my-filter-checkbox', {

    props: ['name', 'label'],

    // DOC: multiline with Template Literals - https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals
    // NOTE: - name="{{name}}": Interpolation inside attributes has been removed. Use v-bind or the colon shorthand instead. For example, instead of <div id="{{ val }}">, use <div :id="val">.
    template: `
    <div id="my-filter-textbox-template">
        <input type="checkbox" :id="name" :name="name" value="1">
        <label :for="name">{{label}}</label>
    </div>`
})

Vue.component('my-details-view', MyDetailsView)
Vue.component('myinfolabel', MyInfoLabel)


const vm = new Vue({
  el: '#app',
  render: h => h(App),
    // does not work. todo: why? (maybe use the full webpack project template)
    // use global registration instead (see above)
//   components: {
//       'my-details-view': MyDetailsView
//   }
})

// This Does not work good (other app will be started as well and element will not be found)
// TODO: try to use a modal dialog https://vuejs.org/v2/examples/modal.html / for now se schnellinfo.html
// new Vue({
//   el: '#app2',
//   render: h => h(App2),
// })
