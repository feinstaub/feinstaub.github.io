"use strict";

const sprintf = require('sprintf-js').sprintf;
const vsprintf = require('sprintf-js').vsprintf;

var mymap = null;
var mymarkerArray = [];

// DOC: https://developer.mozilla.org/en-US/docs/web/javascript/reference/statements/export
export default {

init() {

    mymap = L.map('mapid').setView([51.505, -0.09], 13);

    // from http://leafletjs.com/examples/quick-start/
    //         L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
    //             attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://mapbox.com">Mapbox</a>',
    //             maxZoom: 18,
    //             id: 'mapbox.streets',
    //             accessToken: 'your.mapbox.access.token'
    //         }).addTo(mymap);

    // from https://switch2osm.org/using-tiles/getting-started-with-leaflet/
    // create the tile layer with correct attribution
    var osmUrl='http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
    var osmAttrib='Map data © <a href="http://openstreetmap.org">OpenStreetMap</a> contributors';
    var osm = new L.TileLayer(osmUrl, {minZoom: 5, maxZoom: 100, attribution: osmAttrib});

    // start the map in South-East England
    // mymap.setView(new L.LatLng(51.3, 0.7), 9);

    mymap.addLayer(osm);

    // TEST
    // sampleAddAndZoomMarkers();
    // sampleLeafletQuickstart();
    // TEST END
},

// this was a WORKAROUND: https://stackoverflow.com/questions/42212830/export-function-in-webpack-bundle
//window.rmInit = rmInit;

/**
 * @param {string} dataArray Name, Website, Plz, City, LatLng etc. For detailed spec see createMarkersFromData's documentation
 */
zoomToAllPlaces(dataArray) {

    var sampleData = [];

    dataArray.forEach(function(di) {

        // skip missing entries
        if (!di.LatLng) {
            return;
        }

        sampleData.push({ Name: di.Name, Website: di.Website, Plz: di.Plz, City: di.City, LatLng: di.LatLng });
    });

    // also clears previous markers
    var currentMarkers = createMarkersFromData(mymap, mymarkerArray, sampleData);

    zoomToFit(mymap, currentMarkers);
},

/**
 * Adds marker to the current map and removes all old ones.
 *
 * @param {string} name
 * @param {string} website
 * @param {string} plz
 * @param {string} ort
 * @param {string} latlng array of lat and lng ([49.40747, 8.68792]), NOT to be confused with latlng_str (e.g. "49.40747, 8.68792")
 */
addAndShowMarker(name, website, plz, ort, latlng) {

    if (!latlng) {
        //console.log(sprintf("%s (%s) has no latlng. Reset view.", name, website));
        createMarkersFromData(mymap, mymarkerArray, []);
        return;
    }

    var arr = [
            { Name: name, Website: website, Plz: plz, City: ort, LatLng: latlng } ];
    //console.log(arr);
    var currentMarkers = createMarkersFromData(mymap, mymarkerArray, arr, false);
    currentMarkers[0].openPopup();

    zoomToFit(mymap, currentMarkers);
},

/**
 * doc see below
 */
cooStringToNumberArray,

/**
 * doc see below
 */

cooToOpenstreetmapUrl,

/**
 * doc see below
 */
cooToSatelliteOnGoogleMapsUrl,

/**
 * sample method for testing
 */
sampleAddAndZoomMarkers() {
    var sampleData = createSampleData();
    var currentMarkers = createMarkersFromData(mymap, mymarkerArray, sampleData);
    zoomToFit(mymap, currentMarkers);
}

}

//
// PRIVATE
//


/**
 * Returns the parsed array (latlng[0], latlng[1]) or null if parsing error
 */
function cooStringToNumberArray(latlng_str) {
    var latlng = latlng_str.split(","); //create an array containing lat and lng as strings
    latlng[0] = parseFloat(latlng[0]);
    latlng[1] = parseFloat(latlng[1]);
    // DOC: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/isNaN
    if (isNaN(latlng[0]) || isNaN(latlng[1])) {
        console.log("ratgebermap WARN: latlng_str could not be parsed: " + latlng_str);
        return null;
    }

    return latlng;
}

/**
 * For a given latlng coo as array returns the URL for OpenStreetMap
 * TODO: add unit test
 */
function cooToOpenstreetmapUrl(coo) {
    if (!coo) {
        return null;
    }

    // Example: // https://www.openstreetmap.org/directions?route=%3B49.40746%2C8.68793#map=18/49.40746/8.68700
    // DOC: https://www.npmjs.com/package/sprintf-js
    return sprintf("https://www.openstreetmap.org/?mlat=%1$s&mlon=%2$s#map=18/%1$s/%2$s", coo[0], coo[1]);
}

/**
 * For a given latlng coo as array returns the URL for GoogleMaps' satellite view
 */
function cooToSatelliteOnGoogleMapsUrl(coo) {
    if (!coo) {
        return null;
    }

    // Example: https://www.google.de/maps/@49.6706297,8.686531,1000m/data=!3m1!1e3
    return sprintf("https://www.google.de/maps/@%s,%s,1000m/data=!3m1!1e3", coo[0], coo[1]);
}


var createSampleData = function() {
    return [
            { Name: "Röderhof", Website: "http://biodukte.de/markt/Roederhof-10386", Plz: "64646", City: "Oberhambach", LatLng: [ 49.67104, 8.68909 ] },
            { Name: "Obstmanufaktur Ehret", Website: "https://www.obstmanufaktur-ehret.de", Plz: "64625", City: "Bensheim-Zell", LatLng: [ 49.674704, 8.650961 ] },
            { Name: "Geißehof", Website: "https://www.geissehof.de", Plz: "64658", City: "Fürth/Linnenbach", LatLng: [ 49.65690, 8.75072 ] },
            ];
}

/**
 * 1. Clears any previous markers from markerArray.
 *
 * 2. Adds the markers according to dataArray: array of...
 *    { Name: '...',
 *      Website: '...',
 *      Plz: '...',
 *      City: '...',
 *      LatLng: '...'
 *    }
 *
 * Uses the global variable markerArray.
 *
 * Returns the markerArray.
 */
var createMarkersFromData = function(mymap, markerArray, dataArray, showTooltip = true) {

    // remove all previous markers
    //
    markerArray.forEach(function(layer) {
        // DOC: http://leafletjs.com/reference-1.2.0.html#layer
        //      a marker is a layer
        layer.remove();
    });
    // DOC: clear array: https://appendto.com/2016/02/empty-array-javascript/
    markerArray.length = 0;
    //console.log("cleared");

    // add new markers
    //
    for (var i = 0; i < dataArray.length; i++) {
        var di = dataArray[i]; // dataItem
        //console.log(di);

        // Marker only for additional text
        // https://stackoverflow.com/questions/34775308/leaflet-how-to-add-a-text-label-to-a-custom-marker-icon
//                 var icon = new L.DivIcon({
//                         className: 'my-div-icon',
//                         html: sprintf('<p style="background: white; display: block">%s</p>', di.Name),
//                         iconSize: [ 150, 50 ]
//                     });
//                 // add first to put it to the lower layer
//                 var textMarker = L.marker(di.LatLng, { icon: icon }).addTo(mymap);

        //console.log(di.LatLng);

        // add marker
        //
        // FIXME: shadow is broken, so remove the shadow: DOC: https://stackoverflow.com/questions/23973737/remove-shadow-from-standard-marker-in-leaflet-maps
        var icon = new L.Icon.Default();
        icon.options.shadowSize = [0,0];

        var mainMarker = L.marker(di.LatLng, { title: di.Name, icon: icon }).addTo(mymap);

        // add tooltip to marker
        //
        if (showTooltip) {
            mainMarker.bindTooltip(di.Name, {
                permanent: true,
                direction: 'right'
            });
        }

        // add popup to marker
        //
        var popupStr = sprintf('<b>%s</b>'
                        + '<br><a href="%s" target="_blank">Webseite</a>'
                        + '<br><a href="' + cooToOpenstreetmapUrl(di.LatLng) + '"target="_blank">Große Karte</a>'
                        + '<br><a href="' + cooToSatelliteOnGoogleMapsUrl(di.LatLng) + '"target="_blank">Satelliten-Ansicht</a>'
                        , di.Name, di.Website);
        var popup = mainMarker.bindPopup(popupStr);

        markerArray.push(mainMarker);
    }

    return markerArray;
}

var zoomToFit = function(mymap, markerArray) {
    // https://stackoverflow.com/questions/32861195/automatically-zoom-the-map-to-fit-all-markers
    if (markerArray.length == 0) {
        console.warn("markerArray should contain elements");
    } else if (markerArray.length == 1) {
        // DOC: https://stackoverflow.com/questions/16036824/find-latitude-longitude-of-saved-marker-in-leaflet
        //console.log(markerArray[0].getLatLng());
        mymap.setView(markerArray[0].getLatLng(), 13); // auf 13 ranzoomen
    } else {
        var group = L.featureGroup(markerArray); //add markers array to featureGroup
        // NOTE: hangs when markerArray contains only one element!
        mymap.fitBounds(group.getBounds());
    }
}

var sampleLeafletQuickstart = function() {
    // from http://leafletjs.com/examples/quick-start/
    var marker = L.marker([51.5, -0.09]).addTo(mymap);

    var circle = L.circle([51.508, -0.11], {
        color: 'red',
        fillColor: '#f03',
        fillOpacity: 0.5,
        radius: 500
    }).addTo(mymap);

    var polygon = L.polygon([
        [51.509, -0.08],
        [51.503, -0.06],
        [51.51, -0.047]
    ]).addTo(mymap);

    marker.bindPopup('<b>Hello world!</b><br>I am a popup. <a href="http://www.bund-bergstrasse.de/aktiv_werden/" target="_blank">Aktiv werden beim BUND-Bergstraße</a>').openPopup();
    circle.bindPopup("I am a circle.");
    polygon.bindPopup("I am a polygon.");

    var popup = L.popup()
        .setLatLng([51.5, -0.09])
        .setContent("I am a standalone popup.")
        .openOn(mymap);

    // Röderhof
    var coo = [49.67104, 8.68909];
    var marker = L.marker(coo, { title: 'Röderhof Oberhambach' }).addTo(mymap);
    var roederPopup = marker.bindPopup('<b>Röderhof Oberhambach</b>'
                    + '<br><a href="http://biodukte.de/markt/Roederhof-10386" target="_blank">Webseite</a>'
                    + '<br><a href="' + cooToSatelliteOnGoogleMapsUrl(coo) + '"target="_blank">Satelliten-Ansicht</a>'
                    ).openPopup();

    mymap.setView(new L.LatLng(51.3, 0.7), 9);
}
