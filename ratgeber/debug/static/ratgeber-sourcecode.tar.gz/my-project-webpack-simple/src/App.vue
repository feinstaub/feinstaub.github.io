<template>
  <div id="app">
    <img src="./assets/BUNDlogo2012-1.png" alt="BUND logo" width="150px">
    <h1 id="a_mainheading">{{ msg }} <span style="color: gray">(und anderswo)</span></h1>
    <hr/>
    <!--https://getbootstrap.com/docs/4.0/components/navbar/-->
    <nav class="navbar fixed-top navbar-light bg-light">
        <a href="#a_ergebnisliste">{{ filteredAnbieterData().length }} Treffer</a>
    </nav>
    <div class="my-main-section"><a id="a_suchkriterien">Such-Kriterien:</a>
    <!-- <a href="#a_ergebnisliste">{{ filteredAnbieterData().length }} Treffer</a> -->
    </div>
    <b-container fluid class="my-filter-panel">
        <b-row>
            <!-- DOC: Variable width content - https://bootstrap-vue.js.org/docs/layout/ -->
            <b-col cols="12" md="auto">
                <div class="my-filter-heading">Kategorie:</div>
                <div v-if="filterCategory.length == 0">
                    <b>Bitte mindestens eine Kategorie auswählen</b>
                    <br>
                </div>
                    <!--DOC: https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/checkbox-->
                <div>
                    <input type="checkbox" id="filter-category-direktvermarkter" value="Direktvermarkter" v-model="filterCategory">
                    <label for="filter-category-direktvermarkter">Direktvermarkter</label>
                </div>
                <div>
                    <input type="checkbox" id="filter-category-laden" value="Laden" v-model="filterCategory">
                    <label for="filter-category-laden">Laden / Markt</label>
                </div>
                <div>
                    <input type="checkbox" id="filter-category-restaurant" value="Restaurant" v-model="filterCategory">
                    <label for="filter-category-restaurant">Restaurant / Cafe</label>
                </div>
                <div>
                    <input type="checkbox" id="filter-category-catering" value="Catering" v-model="filterCategory">
                    <label for="filter-category-catering">Catering</label>
                </div>
            </b-col>
            <b-col cols="12" md="auto">
                <div>
                    <div class="my-filter-heading"><b>Bio:</b></div>
                    <input type="radio" id="bio-zertifiziert" value="zertifiziert" v-model="filterEigenschaftBio">
                    <label for="bio-zertifiziert" title="mindestens EU-Standard">zertifiziert</label>
                    <br/>
                    <input type="radio" id="bio-im-angebot" value="imAngebot" v-model="filterEigenschaftBio">
                    <label for="bio-im-angebot">im Angebot</label>
                    <br/>
                    <input type="radio" id="bio-unbekannt" value="unbekannt" v-model="filterEigenschaftBio">
                    <label for="bio-unbekannt" title="egal = oft Landwirtschaft mit hohem Dünger-, Gifteinsatz und Sortenarmut = NICHT EMPFOHLEN">egal</label>
                </div>
            </b-col>
            <b-col cols="12" md="auto">
                <div>
                    <div class="my-filter-heading"><b>Vegetarisch/Vegan:</b></div>
                    <input type="radio" id="tierwohl-vegan" value="vegan" v-model="filterEigenschaftVeg">
                    <label for="tierwohl-vegan" title="vegan = keine Tierprodukte">vegan</label>
                    <br/>
                    <input type="radio" id="tierwohl-vegetarisch" value="vegetarisch-min" v-model="filterEigenschaftVeg">
                    <label for="tierwohl-vegetarisch" title="vegetarisch = kein Fleisch/Fisch">vegetarisch</label>
                    <br/>
                    <input type="radio" id="tierwohl-veganfreundlich" value="veganfreundlich" v-model="filterEigenschaftVeg">
                    <label for="tierwohl-veganfreundlich" title="vegan vorhanden = vegane Produkte sind gut erkennbar oder das Personal kennt sich aus">vegan vorhanden</label>
                    <br/>
                    <input type="radio" id="tierwohl-unbekannt" value="unbekannt" v-model="filterEigenschaftVeg">
                    <label for="tierwohl-unbekannt" title="egal = in der Regel müssen Tiere dafür unnötig leiden = NICHT EMPFOHLEN">egal</label>
                </div>
            </b-col>
            <b-col cols="12" md="auto">
                    <div class="my-filter-heading">Weitere:</div>
                    <input type="checkbox" id="filter-unverpackt" value="1" v-model="filterEigenschaftUnverpackt">
                    <label for="filter-unverpackt" title="Unverpackt = Möglichkeit beim Einkauf Plastik zu reduzieren. Bei Auswahl werden nur Anbieter gelistet, bei denen das 'Unverpackte' etwas Besonderes ist.">Unverpackt (Plastikreduktion)</label>
                    <br/>
                    <input type="checkbox" id="filter-fairtrade" value="1" v-model="filterEigenschaftFairtrade">
                    <label for="filter-fairtrade" title="Fair Trade, insbesondere Kaffee und Kakao und andere Süßwaren. Bei Auswahl werden nur Anbieter gelistet, bei den FairTrade explizit zum Konzept gehört.">Fair Trade (Kaffee, Kakao)</label>
                    <br/>
                    <input type="checkbox" id="filter-veganes-fruehstueck" value="1" v-model="filterProdukteVeganesFruehstueck">
                    <label for="filter-veganes-fruehstueck" title="Es ist möglich allein oder mit Begleitung gemütlich morgens ein Frühstück einzunehmen, das nicht nur aus Brot und Wasser besteht">Vegan frühstücken</label>
                    <br/>
                    <input type="checkbox" id="filter-tiere-einsehbar" value="1" disabled="true">
                    <label for="filter-tiere-einsehbar" title="Nach dem Zotter-Motto 'Schaut dem Essen in die Augen': höchste Transparenz bei der Herkunft der Tierprodukte. Offener Umgang mit allen Aspekten der Tierhaltung, auch den unschönen wie z. B. Schlachtung">Tier-Transparenz</label>
            </b-col>
            <b-col cols="12" md="auto">
                <div class="my-filter-heading">Produktgruppen:</div>
                <input type="checkbox" id="filter-produkte-backwaren" value="1" v-model="filterProdukteBackwaren">
                <label for="filter-produkte-backwaren">Brot / Backwaren</label>
                <br/>
                <input type="checkbox" id="filter-produkte-obstgem" value="1" v-model="filterProdukteObstGem">
                <label for="filter-produkte-obstgem">Obst / Gemüse / Säfte</label>
                <br/>
                <input type="checkbox" id="filter-produkte-honig" value="1" v-model="filterProdukteHonig">
                <label for="filter-produkte-honig">Bienen-Honig</label>
                <br/>
                <input type="checkbox" id="filter-produkte-spirituosen" value="1" v-model="filterProdukteSpirituosen">
                <label for="filter-produkte-spirituosen">Wein / Spirituosen</label>
            </b-col>
            <b-col cols="12" md="auto">
                <div class="my-filter-heading">Umkreis:</div>
                <span style="color: gray">
                Standort im Umkreis von
                <br/>
                |------x------------| 30 km (1 - 500 km)
                <br/>
                um ...Heppenheim...
                <br/>
                [Ändern]</span> / Filter derzeit nicht verfügbar
            </b-col>
            <b-col>
            </b-col>
        </b-row>
    </b-container>

    <!--Ergebnisse-->
    <!-- DOC: bootstrap containers: https://bootstrap-vue.js.org/docs/layout/
            "<b-container fluid> for full width."
    -->
    <hr/>
    <b-container fluid>
        <b-row>
            <b-col style="max-width: 800px">
                <div class="my-main-section"><a id="a_ergebnisliste">Ergebnisliste:</a></div>
                <!--Ergebnis-Tabelle-->
                <!-- nice table style with bootstrap: add table class
                DOC: https://v4-alpha.getbootstrap.com/content/tables/#striped-rows-->
                <table id="my-result-table" class="table table-bordered table-striped" v-if="filteredAnbieterData().length > 0">
                    <!-- DOC: https://vuejs.org/v2/guide/list.html#v-for-with-v-if -->
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>PLZ</th>
                        <th>Stadt</th>
                        <th>Kategorie</th>
                        <th>Aktion</th>
                    </tr>
                </thead>
                <tbody id="my-result-tbody">
                <!-- Highlight active row: DOC: https://v4-alpha.getbootstrap.com/content/tables/#contextual-classes -->
                <tr v-for="item in filteredAnbieterData()" class="result-table-tr" v-bind:class="{ 'table-active': isCurrentItem(item) }" v-on:click="showDetails(item)">
                    <td>{{ item.name }}</td>
                    <td>{{ item.contact.plz }}</td>
                    <td>{{ item.contact.city }}</td>
                    <td>{{ item.category }}</td>
                    <td><a href="#" v-on:click.prevent="showDetails(item)">Details</a> <!--<span v-if="isCurrentItem(item)">-></span>--></td>
                </tr>
                </tbody>
                </table>
                <div v-else>
                    Nichts gefunden.
                </div>
            </b-col>
            <!--Details-->
            <b-col cols="12-md" style="min-width: 500px">
                <div class="row my-main-section">
                    <div class="col-6"><a id="a_detailansicht">Detailansicht:</a></div>
                    <!-- DOC: float-right: https://stackoverflow.com/questions/18672452/left-align-and-right-align-within-div-in-bootstrap -->
                    <div class="col-6"><span class="float-right">
                        <!--DOC: Close button: https://v4-alpha.getbootstrap.com/utilities/close-icon/-->
                        <button type="button" class="close" aria-label="Close" v-on:click="resetDetailsView()" v-if="showDetailsForId > 0">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </span></div>
                </div>
                <div class="ratgeber-detail-view" v-if="showDetailsForId > 0">
                    <div style="padding: 30px; border-style: solid; border-width: 1px; border-color: gray">
                        <my-details-view :detailsItemData="detailsItemData"></my-details-view>
                    </div>
                    <p><a href="#a_ergebnisliste">Zurück zur Liste</a> | <a href="#a_suchkriterien">Neu suchen</a></p>
                    <p><a href="#">Eintrag ergänzen / korrigieren</a> | <a href="#">Neuen Eintrag vorschlagen</a></p>
                </div>
                <div v-else>
                    (Kein Ergebnis ausgewählt)
                    <br/>
                    <br/>
                    <p><a href="#">Neuen Eintrag vorschlagen</a></p>
                </div>
            </b-col>
            <b-col>
                <div id="mapid"></div>
            </b-col>
        </b-row>
    </b-container>
    <hr/>
    <div class="footer">Konsum-Ratgeber <a href="http://www.bund-bergstrasse.de">BUND Bergstraße</a>, <a href="http://www.bund-bergstrasse.de/themen_und_projekte/ernaehrung/">AG Ernährung</a> |
    <!-- version derzeit in dieser Datei definiert -->
    Programm: Version {{version}} (2017 - 2018), Lizenz: <a href="https://de.wikipedia.org/wiki/GNU_Affero_General_Public_License">AGPL</a>,
    <a href="./static/ratgeber-sourcecode.tar.gz">Quellcode</a></div><br/>
    <!--
    <div style="text-align: left">
        Debug-Optionen: <input type="checkbox" v-model="debugShowAnbieterData">Zeige anbieterData</input>
        <div v-if="debugShowAnbieterData">
            {{ anbieterData }}
        </div>
        <my-component></my-component>
        <hello-world></hello-world>
    </div>
    -->
  </div>
</template>

<script>
// DOC: example imports: https://github.com/prograhammer/vue-example-project/blob/master/src/components/App.vue
import RatgeberMap from './ratgebermap.js'
import myutil from './myutil.js'

export default {
  name: 'app',
  data () {
    return {
      version: '0.4.1',
      msg: 'Einkaufsratgeber Ernährung Bergstraße',
      filterCategory: ['Direktvermarkter', 'Laden', 'Restaurant', 'Catering'],
      filterEigenschaftBio: 'imAngebot',
      filterEigenschaftVeg: 'veganfreundlich',
      filterEigenschaftUnverpackt: false,
      filterEigenschaftFairtrade: false,
      filterProdukteBackwaren: false,
      filterProdukteObstGem: false,
      filterProdukteHonig: false,
      filterProdukteSpirituosen: false,
      filterProdukteVeganesFruehstueck: false,
      showDetailsForId: 0,
      detailsItemData: null,
      anbieterData: getAnbieterData(),
      debugShowAnbieterData: false,
      xxx: null
    }
  },
  // DOC: Instance lifecycle hooks - https://vuejs.org/v2/guide/instance.html
  mounted: function () {
    RatgeberMap.init();
    this.resetDetailsView();
  },
  // DOC: https://vuejs.org/v2/guide/computed.html
  methods: {
    filteredAnbieterData: function() {
        // DOC: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter
        return this.anbieterData.filter(this.applyFilter);
    },

    applyFilter: function(item) {
        // DOC: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/includes
        if (!myutil.includes(this.filterCategory, item.category)
            && !myutil.includes(this.filterCategory, item.category2)) { // 'Direktvermarkter', 'Laden', 'Restaurant', 'Catering'
            return false;
        }
        if (this.filterEigenschaftBio == 'zertifiziert'
            && !(item.quality.bio == 'zert')) {
            return false;
        }
        if (this.filterEigenschaftBio == 'imAngebot'
            && (!(item.quality.bio == 'zert') && !(item.quality.bio == 'angebot'))) {
            return false;
        }
        if (myutil.includes(['vegan'], this.filterEigenschaftVeg)
            && !(item.quality.veg == 'vegan')) {
            return false;
        }
        if (myutil.includes(['veganfreundlich', 'vegetarisch-min', 'vegan'], this.filterEigenschaftVeg)
            && !myutil.includes(['min_vegetarisch', 'vegan_freundlich', 'vegan'], item.quality.veg)) {
            return false;
        }
        if (myutil.includes(['vegetarisch-min', 'vegan'], this.filterEigenschaftVeg)
            && !myutil.includes(['min_vegetarisch', 'vegan'], item.quality.veg)) {
            return false;
        }
        if (this.filterEigenschaftFairtrade
            && !item.quality.fairtrade) {
            return false;
        }
        if (this.filterEigenschaftUnverpackt
            && !item.quality.unverpackt) {
            return false;
        }
        if (this.filterProdukteVeganesFruehstueck
            && !item.products.hat_veganes_fruehstueck) {
            return false;
        }
        if (this.filterProdukteBackwaren
            && !item.products.hat_backwaren) {
            return false;
        }
        if (this.filterProdukteObstGem
            && !myutil.includes(item.products.produkt_gruppen, 'Obst') && !myutil.includes(item.products.produkt_gruppen, 'Gemüse')) {
            return false;
        }
        if (this.filterProdukteHonig
            && !myutil.includes(item.products.produkt_gruppen, 'Honig')) {
            return false;
        }
        if (this.filterProdukteSpirituosen
            && !myutil.includes(item.products.produkt_gruppen, 'Spirituosen')) {
            return false;
        }
        return true;
    },
    showDetails: function(item) {
        this.showDetailsForId = item.id;
        this.detailsItemData = item;

        if (item.id > 0) {
            // DOC: https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollIntoView
            // commented out because this causes the view jump around when selecting items in normal/desktop browser
            // var element = document.getElementById("a_detailansicht");
            // element.scrollIntoView();

            RatgeberMap.addAndShowMarker(item.name, item.contact.website, item.contact.plz, item.contact.city, item.contact.latlng_arr);
            //RatgeberMap.sampleAddAndZoomMarkers();
        }
    },
    isCurrentItem: function(item) {
        return this.showDetailsForId == item.id;
    },
    resetDetailsView: function() {
        this.showDetails(0);
        // collect all coordinates out of the currently filtered data and zoom to them:
        RatgeberMap.zoomToAllPlaces(
            this.filteredAnbieterData().map(function(item) {
                return { Name: item.name, Website: item.contact.website, Plz: item.contact.plz, City: item.contact.city, LatLng: item.contact.latlng_arr };
            })
        );
    }
  },
  // DOC: https://vuejs.org/v2/guide/computed.html#Watchers
  // see also (did not work so far) https://vuejs.org/v2/api/#vm-watch (needed for "." properties)
  watch: {
    // reset view if one of the filters is toggled
    filterCategory: function (val) { this.resetDetailsView(); },
    filterEigenschaftBio: function (val) { this.resetDetailsView(); },
    filterEigenschaftVeg: function (val) { this.resetDetailsView(); },
    filterEigenschaftUnverpackt: function (val) { this.resetDetailsView(); },
    filterEigenschaftFairtrade: function (val) { this.resetDetailsView(); },
    filterProdukteVeganesFruehstueck: function (val) { this.resetDetailsView(); },
    filterProdukteBackwaren: function (val) { this.resetDetailsView(); },
    filterProdukteObstGem: function (val) { this.resetDetailsView(); },
    filterProdukteHonig: function (val) { this.resetDetailsView(); },
    filterProdukteSpirituosen: function (val) { this.resetDetailsView(); },
  }
}

/**
 * should be called only once
 */
var getAnbieterData = function() {
    // DOC: https://maketips.net/tip/223/how-to-include-jquery-into-vuejs
    // var $ = window.jQuery = require('jquery');
    // NOTE: !!! not needed when using WebPack's require!!! So we do not add "jquery": "^3.2.1" to package.json
    // DOC: http://api.jquery.com/jquery.getjson/
//     $.getJSON("./assets/export-data-table-2.json", function(data) {
//         console.log(data);
//     })  .done(function() {
//    ...

    // NOTE: for the .json ext we need to modifiy the webpack.config.js, see there and https://stackoverflow.com/questions/27639005/how-to-copy-static-files-to-build-directory-with-webpack
    var dataFile = require("./assets/export-data-table-2.json");
    console.log("json loaded");

    // convert all coordinates to numbers
    //
    dataFile.data.forEach(function(item) {
        if (item.contact.latlng) {
            item.contact.latlng_arr = RatgeberMap.cooStringToNumberArray(item.contact.latlng);
            if (!item.contact.latlng_arr) {
                console.log("WARN: item.contact.latlng could not be parsed: " + item.contact.latlng);
            }
        }
    });

    return dataFile.data;
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 30px;
}

h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}

table#main-filter-table {
    /* DOC: center table: https://stackoverflow.com/questions/7059394/how-to-position-a-table-at-the-center-of-div-horizontally-vertically */
    width: 50%; margin: auto;
}

.my-main-section {
    text-align: left;
    margin-left: 15px;
    margin-top: 15px;
    margin-bottom: 15px;
}

.my-filter-panel {
    text-align: left;
}

.my-filter-heading {
    background-color: lightgray;
    color: black;
    padding: 5px;
    margin-bottom: 10px;
}

#my-result-table {
    height: 400px;
    width: 100%;
    display: inline-block;
    overflow-y: scroll;
}

.result-table-tr td {
    text-align: left;
}

.ratgeber-detail-view {
    text-align: left;
}

.footer {
    /*background-color: lightgray;*/
    font-size: 80%;
}
#mapid {
    height: 400px;
    width: 400px;
}
</style>
