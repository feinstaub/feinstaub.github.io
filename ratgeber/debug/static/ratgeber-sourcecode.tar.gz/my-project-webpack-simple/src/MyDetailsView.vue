<!--
Debug: { "id": 9, "name": "Kaiser Biobäckerei", "category": "Laden", "contact": { "plz": "64646", "city": "z. B. Bahnhof Darmstadt", "street": "...", "latlng": "...", "website": "www.ihre-bio-baeckerei.de", "phone": "06253-6250", "opentimes": "Fr. 16-20.00 Uhr" }, "quality": { "bio": "zert", "veg": "vegan_freundlich", "unverpackt": null, "fairtrade": null }, "products": { "hat_backwaren": true, "hat_veganes_fruehstueck": false, "produkt_gruppen": [ "Backwaren" ] }, "hinweise_besonderheiten": [ "Bäckerei", "Standorte in verschiedenen Städten" ], "created_date": "todo", "created_by": "todo", "modified_date": "todo", "modified_by": "todo" }
-->

<template>
    <div>
        <h3>{{ detailsItemData.name }}</h3>

        <table style="width: 100%">
            <tr>
                <td>
                    <b>{{ detailsItemData.contact.city }}</b>
                </td>
                <td>

                </td>
                <td style="text-align: right">
                    <!--<div style="position: relative; float: right;">-->
                    <span>{{ detailsItemData.category }}</span><span v-if="detailsItemData.category2">, {{ detailsItemData.category2 }}</a></span><span v-if="detailsItemData.contact.website">, <a :href="detailsItemData.contact.website">Webseite</a></span>
                </td>
            </tr>
        </table>

        <div>
            <i>Merkmale</i>:
            <div style="margin-left: 10px">
                <table class="merkmal-table">
                    <tr>
                        <td>
                            Ökologischer Landbau:
                        </td>
                        <td>
                            <!-- fett, wenn nicht unbekannt -->
                            <span v-bind:class="{ 'make-bold': detailsItemData.quality.bio }">{{ qualityBioToString }}</span>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Vegetarisch/Vegan:
                        </td>
                        <td>
                            <span v-bind:class="{ 'make-bold': detailsItemData.quality.veg }">{{ qualityVegToString }}</span>
                        </td>
                    </tr>
                </table>
                <br/>
            </div>
        </div>

        <div v-if="detailsItemData.products.produkt_gruppen.length > 0">
            <i>Ausgewählte Produktgruppen</i>:
            <div style="margin-left: 10px">
                <!-- Der vererbte Listenstil lässt die Produkte nebeneinander erscheinen -->
                <ul>
                    <li v-for="item in detailsItemData.products.produkt_gruppen">{{produktgruppeToString(item)}}</li>
                </ul>
            </div>
        </div>

        <div v-if="detailsItemData.hinweise_besonderheiten.length > 0" style="max-width: 400px">
            <i>Hinweise und Besonderheiten</i>:
            <div style="margin-left: 10px">
                <ul class="my-regular-list">
                    <li v-for="item in detailsItemData.hinweise_besonderheiten">{{item}}</li>
                </ul>
            </div>
        </div>

        <div>
            <i>Kontakt:</i>
            <div style="margin-left: 20px">
                <span v-if="detailsItemData.contact.street">{{ detailsItemData.contact.street }}<br/></span>
                <span v-if="detailsItemData.contact.plz || detailsItemData.contact.city">{{ detailsItemData.contact.plz }} {{ detailsItemData.contact.city }}<br/></span>
                <span v-if="detailsItemData.contact.phone">Telefon: {{ detailsItemData.contact.phone }}<br/></span>
                <span v-if="detailsItemData.contact.opentimes">Öffnungszeiten: {{ detailsItemData.contact.opentimes }}<br/></span>
                <span v-if="detailsItemData.contact.website"><a :href="detailsItemData.contact.website" target="_blank">Webseite</a></span>
                <span v-if="detailsItemData.contact.latlng_arr">| <a :href="bigMapUrl" target="_blank">Große Karte</a></span>
                <!-- find something better than google <span v-if="detailsItemData.contact.latlng_arr">| <a :href="satelliteMapUrl" target="_blank">Satelliten-Ansicht</a></span>-->
            </div>
        </div>

<!--        <div style="max-width: 400px">
            <small>Debug: {{ this.detailsItemData }}</small>
        </div>-->
    </div>
</template>

<script>
import RatgeberMap from './ratgebermap.js'

export default {
  name: 'MyDetailsView',
  props: ['detailsItemData'],
  data () {
    return {
      msg: 'Hallo'
    }
  },
  computed: {
    qualityBioToString: function() {
        var bio = this.detailsItemData.quality.bio;
        if (bio == null) {
            return "keine Infos vorhanden";
        } else if (bio == 'zert') {
            return "Bio-zertifiziert"
        } else if (bio == 'angebot') {
            return "Bio-Produkte im Angebot"
        }
        return "?";
    },
    qualityVegToString: function() {
        var veg = this.detailsItemData.quality.veg;
        if (veg == null) {
            return "keine Infos vorhanden";
        } else if (veg == 'vegan') {
            return "VEGAN"
        } else if (veg == 'min_vegetarisch') {
            return "Rein vegetarisches Angebot"
        } else if (veg == 'vegan_freundlich') {
            return "vegan vorhanden"
        }
        return "?";
    },
    bigMapUrl: function() {
        var a = RatgeberMap.cooToOpenstreetmapUrl(this.detailsItemData.contact.latlng_arr);
        return a;
    },
    satelliteMapUrl: function() {
        return RatgeberMap.cooToSatelliteOnGoogleMapsUrl(this.detailsItemData.contact.latlng_arr);
    }
  },
  methods: {
    produktgruppeToString: function(item) {
        if (item == 'VeganesFrühstück') {
            return "Veganes Frühstück";
        } else {
            return item;
        }
    }
  }
}
</script>

<style>
table.merkmal-table td {
    padding-left: 10px;
}
.make-bold {
    font-weight: bold;
}

ul.my-regular-list {
    list-style-type: circle;
}

ul.my-regular-list li {
    margin-left: 20px;
    /* we have to set this back to list-item because it was changed in App.vue */
    display: list-item;
}

</style>
