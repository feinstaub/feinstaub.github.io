"use strict";

// DOC: https://developer.mozilla.org/en-US/docs/web/javascript/reference/statements/export
export default {

includes(arr, item) {
    // return arr.includes(item); // does not work in IE, see also https://www.npmjs.com/package/babel-plugin-array-includes
    return arr.indexOf(item) >= 0;
}

}
