<template>
    <!--https://bootstrap-vue.js.org/docs/components/collapse/-->
    <span>
        <!-- https://getbootstrap.com/docs/3.3/css/#helper-classes-colors -->

<!--        <span v-b-toggle.infolabel-id1 class="text-muted" :title="text">(ℹ)</span>
        <b-collapse id="infolabel-id1">{{ text }}</b-collapse>-->

    <!--https://bootstrap-vue.js.org/docs/components/collapse/-->
    <span @click="showCollapse = !showCollapse"
           :class="showCollapse ? 'collapsed' : null"
           aria-controls="collapseElem"
           :aria-expanded="showCollapse ? 'true' : 'false'"
           class="text-muted" :title="text">(ℹ)
    </span>
    <b-collapse v-model="showCollapse" id="collapseElem">{{ text }}</b-collapse>

    </span>
</template>

<script>
export default {
    name: 'MyInfoLabel',
    props: ['text'],
    data () {
        return {
            showCollapse: false
        }
   }
}
</script>
