README
------

## Build locally
Yarn seems to be a better cli tool than npm.

Once:

    $ yarn install

Then:

    $ yarn run dev

## NOTE
Build scripts are not included at the moment

## Lizenz
GNU AGPL

## (ORIGINAL README)
### my-project-webpack-simple

> Simple webpack template Vue.js project

### Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```

For detailed explanation on how things work, consult the [docs for vue-loader](http://vuejs.github.io/vue-loader).
