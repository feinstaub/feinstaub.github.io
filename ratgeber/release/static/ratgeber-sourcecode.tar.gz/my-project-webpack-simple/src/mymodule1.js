var sprintf = require('sprintf-js').sprintf;
var vsprintf = require('sprintf-js').vsprintf;

// DOC: https://github.com/prograhammer/vue-example-project/blob/master/src/store/getters.js
export const user = "Hallo User";

// TODO: what is export default?
// see https://github.com/prograhammer/vue-example-project/blob/master/src/store/index.js
// export default store

// TODO: see here: https://github.com/prograhammer/vue-example-project/blob/master/src/auth.js
// export default {
//  ...
//  install(options) {
//  }
//  ...
//  _method(a) {
//  }
//

// TODO: see here: https://github.com/prograhammer/vue-example-project/blob/master/src/utils.js
// module.exports = {
//
//   /**
//    * Get the error from a response.
//    *
//    * @param {Response} response The Vue-resource Response that we will try to get errors from.
//    */
//   getError: function (response) {
//     return response.body['error_description']
//       ? response.body.error_description
//       : response.statusText
//   }
// }

// TODO: see
//   https://github.com/prograhammer/vue-example-project/blob/master/src/main.js            import router from './router'
//   https://github.com/prograhammer/vue-example-project/blob/master/src/router/index.js
//

const store = "Storefront";

export default store;
