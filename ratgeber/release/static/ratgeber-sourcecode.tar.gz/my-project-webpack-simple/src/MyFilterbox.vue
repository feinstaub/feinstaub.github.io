<template>
    <div>
        <input type="checkbox" id="a" value="1" v-model="filterCategoryLaden">
        <label for="a">Laden</label>
    </div>
</template>

<script>
</script>

// TODO:
// - https://alligator.io/vuejs/add-v-model-support/
// - https://www.smashingmagazine.com/2017/08/creating-custom-inputs-vue-js/
// - https://vuejs.org/v2/guide/forms.html#Basic-Usage
// - https://github.com/nylira/vue-input
